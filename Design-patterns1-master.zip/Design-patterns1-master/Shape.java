package com.epam.design_pats;
public interface Shape {
   void draw();
}