package com.epam.design_pats;
public interface Image {
   void display();
}